<template>
  <div
    class="dsc-page-number absolute bottom-3 right-7 z-50 min-w-[7rem] text-right pointer-events-none select-none text-[12px] font-mono tracking-wider text-slate-400/80"
    :aria-label="`Slide ${$nav.currentPage} of ${$nav.total}`"
  >
    {{ $nav.currentPage }} / {{ $nav.total }}
  </div>
</template>
