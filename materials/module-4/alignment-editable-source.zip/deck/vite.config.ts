import { fileURLToPath } from 'node:url'
const deckRoot = fileURLToPath(new URL('.', import.meta.url))
export default { cacheDir: './.cache/vite', server: { fs: { allow: [deckRoot] } } }
