DSC261 Alignment and Post-training

100 slides: 99 main and 1 optional. October 27: 59 pages; October 29: 41 pages.

Three core papers retain their technical depth, worked examples, exercises and feedback. Revised opening uses complete incident narratives and compact clickable original-source screenshots. METR investigation is a bounded case, not proof of deceptive alignment. Full spoken script, editable source, offline HTML, source maps and verification records accompany the audience PDF. Timing remains provisional.
